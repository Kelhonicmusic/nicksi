from django.apps import AppConfig


class EnglishSchoolConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'english_school'
